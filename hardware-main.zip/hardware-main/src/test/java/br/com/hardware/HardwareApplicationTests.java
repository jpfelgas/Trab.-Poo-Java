package br.com.hardware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HardwareApplicationTests {

	@Test
	void contextLoads() {
	}

}
