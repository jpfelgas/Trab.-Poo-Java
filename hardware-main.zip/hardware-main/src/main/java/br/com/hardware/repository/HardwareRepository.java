
package br.com.hardware.repository;

import br.com.hardware.model.Hardware;
import org.springframework.data.repository.CrudRepository;

public interface HardwareRepository extends CrudRepository<Hardware,Long>{
    
}

